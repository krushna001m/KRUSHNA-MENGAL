import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import QuestionGenerator from "@/components/question-generator"
import ExamBuilder from "@/components/exam-builder"
import QuestionBank from "@/components/question-bank"

export default function Home() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">AI-Powered Exam Paper Generator</h1>

      <Tabs defaultValue="generate" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="generate">Generate Questions</TabsTrigger>
          <TabsTrigger value="build">Build Exam</TabsTrigger>
          <TabsTrigger value="bank">Question Bank</TabsTrigger>
        </TabsList>

        <TabsContent value="generate">
          <QuestionGenerator />
        </TabsContent>

        <TabsContent value="build">
          <ExamBuilder />
        </TabsContent>

        <TabsContent value="bank">
          <QuestionBank />
        </TabsContent>
      </Tabs>
    </div>
  )
}

