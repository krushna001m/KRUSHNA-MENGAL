"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { Question } from "./types"
import { v4 as uuidv4 } from "uuid"

// In-memory storage for questions (in a real app, this would be a database)
let questions: Question[] = []

export async function generateQuestion(params: {
  subject: string
  topic: string
  difficulty: string
  taxonomyLevel: string
  questionType: string
}) {
  const { subject, topic, difficulty, taxonomyLevel, questionType } = params

  // Check if OpenAI API key is available
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OpenAI API key is missing. Please add it to your environment variables.")
  }

  const prompt = `
    Generate a ${difficulty} level ${questionType} question on ${subject}, specifically about ${topic}.
    The question should be at the ${taxonomyLevel} level of Bloom's Taxonomy.
    
    ${questionType === "MCQ" ? "Include 4 options with the correct answer marked." : ""}
    
    Format your response as:
    Question: [The question text]
    ${questionType === "MCQ" ? "Options: [The options]" : ""}
    Answer: [The correct answer or solution]
  `

  try {
    const { text } = await generateText({
      model: openai("gpt-4o", { apiKey: process.env.OPENAI_API_KEY }),
      prompt,
    })

    // Parse the response to extract question and answer
    const questionMatch = text.match(/Question:(.*?)(?=Answer:|$)/s)
    const answerMatch = text.match(/Answer:(.*?)(?=$)/s)

    const questionText = questionMatch ? questionMatch[1].trim() : text
    const answerText = answerMatch ? answerMatch[1].trim() : ""

    return {
      question: questionText,
      answer: answerText,
    }
  } catch (error) {
    console.error("Error generating question:", error)
    throw new Error("Failed to generate question. Please check your OpenAI API key and try again.")
  }
}

export async function saveQuestion(question: Omit<Question, "id" | "createdAt">) {
  try {
    const newQuestion: Question = {
      ...question,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }

    questions.push(newQuestion)
    return newQuestion
  } catch (error) {
    console.error("Error saving question:", error)
    throw new Error("Failed to save question")
  }
}

export async function getQuestions(): Promise<Question[]> {
  // In a real app, this would fetch from a database
  return [...questions].sort((a, b) => {
    return new Date(b.createdAt || "").getTime() - new Date(a.createdAt || "").getTime()
  })
}

export async function deleteQuestion(id: string) {
  try {
    questions = questions.filter((q) => q.id !== id)
    return { success: true }
  } catch (error) {
    console.error("Error deleting question:", error)
    throw new Error("Failed to delete question")
  }
}

export async function updateQuestion(question: Question) {
  try {
    const index = questions.findIndex((q) => q.id === question.id)
    if (index !== -1) {
      questions[index] = question
    }
    return { success: true }
  } catch (error) {
    console.error("Error updating question:", error)
    throw new Error("Failed to update question")
  }
}

export async function generateExamPaper(params: {
  title: string
  subject: string
  duration: number
  totalMarks: number
  questions: Question[]
}) {
  const { title, subject, duration, totalMarks, questions } = params

  try {
    // Format the exam paper
    let examPaper = `
${title.toUpperCase()}
Subject: ${subject}
Duration: ${duration} minutes
Total Marks: ${totalMarks}
-------------------------------------------------

INSTRUCTIONS:
- Answer all questions.
- Write your answers clearly and legibly.
- Show all your work for full credit.

-------------------------------------------------

`

    // Add questions to the exam paper
    questions.forEach((q, index) => {
      const questionNumber = index + 1
      const questionMarks = Math.round(totalMarks / questions.length)

      examPaper += `
Question ${questionNumber} (${questionMarks} marks) - ${q.taxonomyLevel} level
${q.questionText}

`

      if (q.questionType === "MCQ") {
        // Extract options if it's an MCQ
        const optionsMatch = q.questionText.match(/Options:(.*?)(?=$)/s)
        if (optionsMatch) {
          examPaper += optionsMatch[1].trim() + "\n\n"
        }
      }
    })

    // Add answer key at the end
    examPaper += `
-------------------------------------------------
ANSWER KEY (For Teacher's Reference Only)
-------------------------------------------------

`

    questions.forEach((q, index) => {
      examPaper += `Question ${index + 1}: ${q.answerText}\n\n`
    })

    return { examPaper }
  } catch (error) {
    console.error("Error generating exam paper:", error)
    throw new Error("Failed to generate exam paper")
  }
}

export async function checkSimilarity(questionId: string, questionText: string) {
  try {
    // Get all questions except the current one
    const otherQuestions = questions.filter((q) => q.id !== questionId)

    // Calculate similarity using a simple algorithm
    // In a real app, you would use a more sophisticated approach like TF-IDF or embeddings
    const results = otherQuestions.map((q) => {
      const similarity = calculateJaccardSimilarity(questionText.toLowerCase(), q.questionText.toLowerCase())

      return {
        id: q.id,
        similarity,
      }
    })

    // Sort by similarity (highest first) and take top 5
    return results.sort((a, b) => b.similarity - a.similarity).slice(0, 5)
  } catch (error) {
    console.error("Error checking similarity:", error)
    throw new Error("Failed to check similarity")
  }
}

// Simple Jaccard similarity implementation
function calculateJaccardSimilarity(text1: string, text2: string): number {
  const words1 = new Set(text1.split(/\s+/).filter(Boolean))
  const words2 = new Set(text2.split(/\s+/).filter(Boolean))

  const intersection = new Set([...words1].filter((x) => words2.has(x)))
  const union = new Set([...words1, ...words2])

  return intersection.size / union.size
}

