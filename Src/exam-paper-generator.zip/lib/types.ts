export interface Question {
  id: string
  subject: string
  topic: string
  difficulty: string
  taxonomyLevel: string
  questionType: string
  questionText: string
  answerText: string
  createdAt?: string
}

export interface ExamPaper {
  title: string
  subject: string
  duration: number
  totalMarks: number
  questions: Question[]
}

