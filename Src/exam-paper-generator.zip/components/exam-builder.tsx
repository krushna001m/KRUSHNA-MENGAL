"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, FileDown } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { getQuestions, generateExamPaper } from "@/lib/actions"
import type { Question } from "@/lib/types"
import { Checkbox } from "@/components/ui/checkbox"

export default function ExamBuilder() {
  const [examTitle, setExamTitle] = useState("")
  const [subject, setSubject] = useState("")
  const [duration, setDuration] = useState("")
  const [totalMarks, setTotalMarks] = useState("")
  const [questions, setQuestions] = useState<Question[]>([])
  const [selectedQuestions, setSelectedQuestions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [examPaper, setExamPaper] = useState("")

  useEffect(() => {
    const loadQuestions = async () => {
      setIsLoading(true)
      try {
        const fetchedQuestions = await getQuestions()
        setQuestions(fetchedQuestions)
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load questions. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadQuestions()
  }, [])

  const handleGenerateExam = async () => {
    if (!examTitle || !subject || !duration || !totalMarks) {
      toast({
        title: "Missing fields",
        description: "Please fill in all exam details.",
        variant: "destructive",
      })
      return
    }

    if (selectedQuestions.length === 0) {
      toast({
        title: "No questions selected",
        description: "Please select at least one question for the exam.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    try {
      const selectedQuestionObjects = questions.filter((q) => selectedQuestions.includes(q.id))

      const result = await generateExamPaper({
        title: examTitle,
        subject,
        duration: Number.parseInt(duration),
        totalMarks: Number.parseInt(totalMarks),
        questions: selectedQuestionObjects,
      })

      setExamPaper(result.examPaper)

      toast({
        title: "Success",
        description: "Exam paper generated successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate exam paper. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleToggleQuestion = (id: string) => {
    setSelectedQuestions((prev) => (prev.includes(id) ? prev.filter((qId) => qId !== id) : [...prev, id]))
  }

  const handleDownload = () => {
    if (!examPaper) return

    const blob = new Blob([examPaper], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${examTitle.replace(/\s+/g, "_")}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="examTitle">Exam Title</Label>
            <Input
              id="examTitle"
              placeholder="e.g., Midterm Examination"
              value={examTitle}
              onChange={(e) => setExamTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              placeholder="e.g., Mathematics"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration">Duration (minutes)</Label>
            <Input
              id="duration"
              type="number"
              placeholder="e.g., 120"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="totalMarks">Total Marks</Label>
            <Input
              id="totalMarks"
              type="number"
              placeholder="e.g., 100"
              value={totalMarks}
              onChange={(e) => setTotalMarks(e.target.value)}
            />
          </div>

          <Button onClick={handleGenerateExam} className="w-full" disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Exam...
              </>
            ) : (
              "Generate Exam Paper"
            )}
          </Button>

          {examPaper && (
            <Button variant="outline" className="w-full" onClick={handleDownload}>
              <FileDown className="mr-2 h-4 w-4" />
              Download Exam Paper
            </Button>
          )}
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Selected Questions ({selectedQuestions.length})</Label>
            <div className="border rounded-md p-4 h-[400px] overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : questions.length > 0 ? (
                <div className="space-y-2">
                  {questions.map((question) => (
                    <div key={question.id} className="flex items-start space-x-2 p-2 border rounded-md">
                      <Checkbox
                        id={question.id}
                        checked={selectedQuestions.includes(question.id)}
                        onCheckedChange={() => handleToggleQuestion(question.id)}
                        className="mt-1"
                      />
                      <div className="space-y-1 flex-1">
                        <Label htmlFor={question.id} className="font-medium cursor-pointer">
                          {question.questionText.length > 100
                            ? `${question.questionText.substring(0, 100)}...`
                            : question.questionText}
                        </Label>
                        <div className="text-xs text-muted-foreground">
                          {question.subject} | {question.topic} | {question.difficulty} | {question.taxonomyLevel}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <p>No questions available in the question bank.</p>
                  <p className="text-sm">Generate and save questions first.</p>
                </div>
              )}
            </div>
          </div>

          {examPaper && (
            <div className="space-y-2">
              <Label>Generated Exam Paper</Label>
              <Textarea className="min-h-[200px]" value={examPaper} readOnly />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

