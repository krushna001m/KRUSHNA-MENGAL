"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { generateQuestion } from "@/lib/actions"
import { Loader2, Save, RefreshCw } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { saveQuestion } from "@/lib/actions"

export default function QuestionGenerator() {
  const [subject, setSubject] = useState("")
  const [topic, setTopic] = useState("")
  const [difficulty, setDifficulty] = useState("")
  const [taxonomyLevel, setTaxonomyLevel] = useState("")
  const [questionType, setQuestionType] = useState("")
  const [generatedQuestion, setGeneratedQuestion] = useState("")
  const [generatedAnswer, setGeneratedAnswer] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  const handleGenerate = async () => {
    if (!subject || !topic || !difficulty || !taxonomyLevel || !questionType) {
      toast({
        title: "Missing fields",
        description: "Please fill in all fields to generate a question.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    try {
      const result = await generateQuestion({
        subject,
        topic,
        difficulty,
        taxonomyLevel,
        questionType,
      })

      setGeneratedQuestion(result.question)
      setGeneratedAnswer(result.answer)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to generate question. Please try again."
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSave = async () => {
    if (!generatedQuestion) {
      toast({
        title: "No question to save",
        description: "Please generate a question first.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    try {
      await saveQuestion({
        subject,
        topic,
        difficulty,
        taxonomyLevel,
        questionType,
        questionText: generatedQuestion,
        answerText: generatedAnswer,
      })

      toast({
        title: "Success",
        description: "Question saved to the question bank.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save question. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              placeholder="e.g., Mathematics, Physics, Biology"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="topic">Topic</Label>
            <Input
              id="topic"
              placeholder="e.g., Algebra, Mechanics, Cell Biology"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="difficulty">Difficulty Level</Label>
            <Select value={difficulty} onValueChange={setDifficulty}>
              <SelectTrigger>
                <SelectValue placeholder="Select difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Easy">Easy</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Hard">Hard</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="taxonomy">Bloom's Taxonomy Level</Label>
            <Select value={taxonomyLevel} onValueChange={setTaxonomyLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Select taxonomy level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Remember">Remember</SelectItem>
                <SelectItem value="Understand">Understand</SelectItem>
                <SelectItem value="Apply">Apply</SelectItem>
                <SelectItem value="Analyze">Analyze</SelectItem>
                <SelectItem value="Evaluate">Evaluate</SelectItem>
                <SelectItem value="Create">Create</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="questionType">Question Type</Label>
            <Select value={questionType} onValueChange={setQuestionType}>
              <SelectTrigger>
                <SelectValue placeholder="Select question type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MCQ">Multiple Choice</SelectItem>
                <SelectItem value="Short">Short Answer</SelectItem>
                <SelectItem value="Long">Long Answer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} className="w-full" disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Question"
            )}
          </Button>
        </div>

        <div className="space-y-4">
          <Card className="min-h-[300px]">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <Label>Generated Question</Label>
                <Textarea
                  className="min-h-[150px]"
                  placeholder="Generated question will appear here..."
                  value={generatedQuestion}
                  onChange={(e) => setGeneratedQuestion(e.target.value)}
                />
              </div>

              <div className="space-y-2 mt-4">
                <Label>Answer</Label>
                <Textarea
                  className="min-h-[100px]"
                  placeholder="Answer will appear here..."
                  value={generatedAnswer}
                  onChange={(e) => setGeneratedAnswer(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex space-x-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleGenerate}
              disabled={isGenerating || !subject || !topic || !difficulty || !taxonomyLevel || !questionType}
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Regenerate
            </Button>

            <Button className="flex-1" onClick={handleSave} disabled={isSaving || !generatedQuestion}>
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save to Bank
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

