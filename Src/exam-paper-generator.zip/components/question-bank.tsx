"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Search, Trash2, Edit, Save } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { getQuestions, deleteQuestion, updateQuestion } from "@/lib/actions"
import type { Question } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { checkSimilarity } from "@/lib/actions"

export default function QuestionBank() {
  const [questions, setQuestions] = useState<Question[]>([])
  const [filteredQuestions, setFilteredQuestions] = useState<Question[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [subjectFilter, setSubjectFilter] = useState("")
  const [difficultyFilter, setDifficultyFilter] = useState("")
  const [taxonomyFilter, setTaxonomyFilter] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editedQuestion, setEditedQuestion] = useState<Question | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [isChecking, setIsChecking] = useState(false)
  const [similarityResults, setSimilarityResults] = useState<{ id: string; similarity: number }[]>([])

  useEffect(() => {
    loadQuestions()
  }, [])

  useEffect(() => {
    filterQuestions()
  }, [questions, searchTerm, subjectFilter, difficultyFilter, taxonomyFilter])

  const loadQuestions = async () => {
    setIsLoading(true)
    try {
      const fetchedQuestions = await getQuestions()
      setQuestions(fetchedQuestions)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load questions. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filterQuestions = () => {
    let filtered = [...questions]

    if (searchTerm) {
      filtered = filtered.filter(
        (q) =>
          q.questionText.toLowerCase().includes(searchTerm.toLowerCase()) ||
          q.topic.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (subjectFilter) {
      filtered = filtered.filter((q) => q.subject === subjectFilter)
    }

    if (difficultyFilter) {
      filtered = filtered.filter((q) => q.difficulty === difficultyFilter)
    }

    if (taxonomyFilter) {
      filtered = filtered.filter((q) => q.taxonomyLevel === taxonomyFilter)
    }

    setFilteredQuestions(filtered)
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteQuestion(id)
      setQuestions(questions.filter((q) => q.id !== id))
      toast({
        title: "Success",
        description: "Question deleted successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete question. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEdit = (question: Question) => {
    setEditingId(question.id)
    setEditedQuestion({ ...question })
  }

  const handleSave = async () => {
    if (!editedQuestion) return

    setIsSaving(true)
    try {
      await updateQuestion(editedQuestion)
      setQuestions(questions.map((q) => (q.id === editedQuestion.id ? editedQuestion : q)))
      setEditingId(null)
      setEditedQuestion(null)
      toast({
        title: "Success",
        description: "Question updated successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update question. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setEditedQuestion(null)
  }

  const handleCheckSimilarity = async (question: Question) => {
    setIsChecking(true)
    setSimilarityResults([])
    try {
      const results = await checkSimilarity(question.id, question.questionText)
      setSimilarityResults(results)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check similarity. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsChecking(false)
    }
  }

  const getUniqueSubjects = () => {
    return [...new Set(questions.map((q) => q.subject))]
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search questions..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <Select value={subjectFilter} onValueChange={setSubjectFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subjects</SelectItem>
            {getUniqueSubjects().map((subject) => (
              <SelectItem key={subject} value={subject}>
                {subject}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Difficulties</SelectItem>
            <SelectItem value="Easy">Easy</SelectItem>
            <SelectItem value="Medium">Medium</SelectItem>
            <SelectItem value="Hard">Hard</SelectItem>
          </SelectContent>
        </Select>

        <Select value={taxonomyFilter} onValueChange={setTaxonomyFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Taxonomy Level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            <SelectItem value="Remember">Remember</SelectItem>
            <SelectItem value="Understand">Understand</SelectItem>
            <SelectItem value="Apply">Apply</SelectItem>
            <SelectItem value="Analyze">Analyze</SelectItem>
            <SelectItem value="Evaluate">Evaluate</SelectItem>
            <SelectItem value="Create">Create</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredQuestions.length > 0 ? (
          <Accordion type="single" collapsible className="w-full">
            {filteredQuestions.map((question) => (
              <AccordionItem key={question.id} value={question.id}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <div className="font-medium">
                      {question.questionText.length > 100
                        ? `${question.questionText.substring(0, 100)}...`
                        : question.questionText}
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <Badge variant="outline">{question.subject}</Badge>
                      <Badge variant="outline">{question.topic}</Badge>
                      <Badge
                        variant={
                          question.difficulty === "Easy"
                            ? "secondary"
                            : question.difficulty === "Medium"
                              ? "default"
                              : "destructive"
                        }
                      >
                        {question.difficulty}
                      </Badge>
                      <Badge variant="outline">{question.taxonomyLevel}</Badge>
                      <Badge variant="outline">{question.questionType}</Badge>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  {editingId === question.id && editedQuestion ? (
                    <div className="space-y-4 p-4 border rounded-md">
                      <div className="space-y-2">
                        <Label>Question</Label>
                        <Textarea
                          value={editedQuestion.questionText}
                          onChange={(e) => setEditedQuestion({ ...editedQuestion, questionText: e.target.value })}
                          className="min-h-[100px]"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Answer</Label>
                        <Textarea
                          value={editedQuestion.answerText}
                          onChange={(e) => setEditedQuestion({ ...editedQuestion, answerText: e.target.value })}
                          className="min-h-[100px]"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Subject</Label>
                          <Input
                            value={editedQuestion.subject}
                            onChange={(e) => setEditedQuestion({ ...editedQuestion, subject: e.target.value })}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Topic</Label>
                          <Input
                            value={editedQuestion.topic}
                            onChange={(e) => setEditedQuestion({ ...editedQuestion, topic: e.target.value })}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Difficulty</Label>
                          <Select
                            value={editedQuestion.difficulty}
                            onValueChange={(value) => setEditedQuestion({ ...editedQuestion, difficulty: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Easy">Easy</SelectItem>
                              <SelectItem value="Medium">Medium</SelectItem>
                              <SelectItem value="Hard">Hard</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Taxonomy Level</Label>
                          <Select
                            value={editedQuestion.taxonomyLevel}
                            onValueChange={(value) => setEditedQuestion({ ...editedQuestion, taxonomyLevel: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Remember">Remember</SelectItem>
                              <SelectItem value="Understand">Understand</SelectItem>
                              <SelectItem value="Apply">Apply</SelectItem>
                              <SelectItem value="Analyze">Analyze</SelectItem>
                              <SelectItem value="Evaluate">Evaluate</SelectItem>
                              <SelectItem value="Create">Create</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={handleCancelEdit}>
                          Cancel
                        </Button>
                        <Button onClick={handleSave} disabled={isSaving}>
                          {isSaving ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Save Changes
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4 p-4">
                      <div className="space-y-2">
                        <Label className="font-medium">Question:</Label>
                        <div className="p-3 bg-muted rounded-md">{question.questionText}</div>
                      </div>

                      <div className="space-y-2">
                        <Label className="font-medium">Answer:</Label>
                        <div className="p-3 bg-muted rounded-md">{question.answerText}</div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(question)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(question.id)}>
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCheckSimilarity(question)}
                          disabled={isChecking}
                        >
                          {isChecking ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Checking...
                            </>
                          ) : (
                            <>
                              <Search className="mr-2 h-4 w-4" />
                              Check Similarity
                            </>
                          )}
                        </Button>
                      </div>

                      {similarityResults.length > 0 && (
                        <div className="mt-4 p-3 border rounded-md">
                          <Label className="font-medium">Similarity Results:</Label>
                          <div className="mt-2 space-y-2">
                            {similarityResults.map((result) => {
                              const similarQuestion = questions.find((q) => q.id === result.id)
                              return (
                                <div key={result.id} className="p-2 bg-muted rounded-md">
                                  <div className="flex justify-between">
                                    <div className="text-sm font-medium">
                                      {similarQuestion?.questionText.substring(0, 100)}...
                                    </div>
                                    <Badge variant={result.similarity > 0.75 ? "destructive" : "outline"}>
                                      {(result.similarity * 100).toFixed(1)}% similar
                                    </Badge>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
            <p>No questions found.</p>
            {questions.length > 0 ? (
              <p className="text-sm">Try adjusting your filters.</p>
            ) : (
              <p className="text-sm">Generate and save questions first.</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

